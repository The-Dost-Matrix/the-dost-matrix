import type { EntityId, IsoDateTime } from "@/core/contracts/v2";
import {
  assertIsoDateTime,
  assertNonEmptyString,
  assertNonNegativeNumber,
  isOneOf,
} from "@/core/contracts/v2";

export const MISSION_STATUSES = [
  "DRAFT",
  "READY",
  "ACTIVE",
  "WAITING_FOR_ROLE",
  "WAITING_FOR_OWNER",
  "WAITING_FOR_APPROVAL",
  "REPLANNING",
  "PAUSED",
  "COMPLETED",
  "FAILED",
  "CANCELLED",
] as const;

export type MissionStatus = (typeof MISSION_STATUSES)[number];
export type MissionRiskLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
export type MissionApprovalState =
  | "NOT_REQUIRED"
  | "PENDING"
  | "APPROVED"
  | "REJECTED";
/**
 * "UNDETERMINED" (stap 12b): QA kon dit criterium niet vaststellen — niet
 * omdat het niet klopt, maar omdat de benodigde informatie ontbrak in wat ze
 * kreeg (bijvoorbeeld: het criterium vraagt om iets dat alleen door
 * daadwerkelijk uitvoeren is vast te stellen). Bewust een aparte waarde en
 * geen (verkapt) FAILED: een geforceerd NIET GEHAALD startte tot nu toe een
 * inhoudelijke herstellus (zie semantic-repair.ts) die nooit kon slagen,
 * omdat er niets inhoudelijk mis was om te herstellen — alleen iets om vast
 * te stellen. Zie owner-clarification.ts voor wat hierna gebeurt: de
 * Director vraagt het aan de eigenaar in plaats van de Builder eindeloos
 * dezelfde reparatie te laten proberen.
 */
export type CriterionStatus = "PENDING" | "PASSED" | "FAILED" | "UNDETERMINED";
export type AssignmentStatus =
  | "ACTIVE"
  | "COMPLETED"
  | "FAILED"
  | "WAITING_FOR_INPUT"
  | "CANCELLED";

export interface MissionBudget {
  maximumCost: number;
  currency: string;
}

export interface MissionCriterion {
  criterionId: EntityId;
  description: string;
  status: CriterionStatus;
  evidenceRefs: EntityId[];
  evaluatedAt?: IsoDateTime;
  /**
   * Toelichting van de laatste beoordeling (meestal van de qa-rol), bv.
   * "geen CSS zichtbaar in de diff". Bewaard zodat de Director dit bij een
   * volgende beslissing kan meenemen — zonder dit veld zag de Director bij
   * een FAILED-criterium alleen de kale omschrijving terug, niet WAAROM het
   * niet gehaald was, waardoor een nieuwe poging even ongericht kon zijn als
   * de vorige.
   */
  lastEvaluationNote?: string;
}

/**
 * Waarom een toewijzing is uitgezet.
 *
 * "TECHNICAL_REPAIR" is een herstelpoging na een mislukte CI-controle
 * (roadmapstap 11); "SEMANTIC_REPAIR" is een herstelpoging nadat QA een
 * succescriterium afkeurde terwijl de CI groen is (roadmapstap 12).
 * Bewust twee waarden en geen gedeelde teller: het zijn verschillende
 * soorten problemen, en drie mislukte compileerreparaties zeggen niets over
 * hoeveel inhoudelijke rondes nog zinvol zijn. Het staat als eigen veld en niet als iets dat je uit de
 * opdrachttekst kunt afleiden: op die tekst tellen zou breken zodra de
 * formulering verandert — dezelfde reden waarom stap 5 de string-matching op
 * foutmeldingen heeft vervangen door foutcodes.
 *
 * Optioneel, zodat toewijzingen van vóór deze wijziging geldig blijven; die
 * tellen als gewone opdracht.
 */
export type AssignmentKind = "BUILD" | "TECHNICAL_REPAIR" | "SEMANTIC_REPAIR";

export interface MissionAssignmentRecord {
  assignmentId: EntityId;
  decisionId: EntityId;
  roleId: EntityId;
  status: AssignmentStatus;
  objective: string;
  successCriteria: string[];
  kind?: AssignmentKind;
  resultId?: EntityId;
  /**
   * Samenvatting van het laatste RoleResult op deze toewijzing (zie
   * RoleResult.summary in contracts/v2/role-result.ts), hier gedupliceerd
   * omdat Mission Engine V2 de volledige inhoud van een RoleResult verder
   * nergens doorzoekbaar bewaart (zie ook findMissionPullRequest in
   * qa-runtime.ts). Nodig voor stap 12b: wanneer de Director de eigenaar een
   * vraag stelt over een criterium waar de Builder al een weerwoord op had
   * (de inhoudelijke herstelpoging uit stap 12), moet dat weerwoord voor de
   * eigenaar zichtbaar blijven — niet alleen kortstondig in de UI van het
   * moment zelf. Zie findLatestBuilderRebuttal in owner-clarification.ts.
   */
  resultSummary?: string;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface PendingOwnerInput {
  requestId: EntityId;
  question: string;
  requestedAt: IsoDateTime;
  /**
   * Stap 12b: wanneer gezet, gaat dit verzoek over dit specifieke
   * succescriterium — het antwoord van de eigenaar (zie recordOwnerInput in
   * engine.ts) mag dit criterium dan direct op GEHAALD/NIET GEHAALD zetten,
   * in plaats van alleen de missie te hervatten. Ontbreekt bij een generiek
   * inputverzoek (bijvoorbeeld vanuit een WAITING_FOR_INPUT-rolresultaat,
   * zie recordRoleResult in engine.ts) — daar verandert het antwoord van de
   * eigenaar geen enkel criterium, exact het gedrag van vóór deze stap.
   */
  relatedCriterionId?: EntityId;
}

export interface PendingApproval {
  approvalId: EntityId;
  action: string;
  reason: string;
  requestedAt: IsoDateTime;
}

export interface MissionV2 {
  missionId: EntityId;
  ownerId: EntityId;
  projectId: EntityId;
  goalRefs: EntityId[];
  title: string;
  objective: string;
  status: MissionStatus;
  priority: number;
  riskLevel: MissionRiskLevel;
  budget: MissionBudget;
  spentCost: number;
  successCriteria: MissionCriterion[];
  constraints: string[];
  currentDecisionId?: EntityId;
  assignments: MissionAssignmentRecord[];
  activeAssignmentIds: EntityId[];
  ownerApprovalState: MissionApprovalState;
  pendingOwnerInput?: PendingOwnerInput;
  pendingApproval?: PendingApproval;
  version: number;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
  completedAt?: IsoDateTime;
  failureReason?: string;
  cancellationReason?: string;
}

export function assertMission(mission: MissionV2): asserts mission is MissionV2 {
  assertNonEmptyString(mission.missionId, "missionId");
  assertNonEmptyString(mission.ownerId, "ownerId");
  assertNonEmptyString(mission.projectId, "projectId");
  assertNonEmptyString(mission.title, "title");
  assertNonEmptyString(mission.objective, "objective");
  assertNonEmptyString(mission.budget.currency, "budget.currency");
  assertNonNegativeNumber(mission.budget.maximumCost, "budget.maximumCost");
  assertNonNegativeNumber(mission.spentCost, "spentCost");
  assertIsoDateTime(mission.createdAt, "createdAt");
  assertIsoDateTime(mission.updatedAt, "updatedAt");

  if (!isOneOf(mission.status, MISSION_STATUSES)) {
    throw new Error(`Onbekende mission status: ${mission.status}`);
  }
  if (!Number.isInteger(mission.priority) || mission.priority < 0) {
    throw new Error("priority moet een niet-negatief geheel getal zijn.");
  }
  if (!Number.isInteger(mission.version) || mission.version < 1) {
    throw new Error("version moet minimaal 1 zijn.");
  }
  if (mission.goalRefs.length === 0) {
    throw new Error("Een mission moet minimaal één goal refereren.");
  }
  if (mission.successCriteria.length === 0) {
    throw new Error("Een mission moet minimaal één succescriterium hebben.");
  }
  // Bewust GEEN handhaving hier (vroeger stond hier een throw zodra
  // spentCost > budget.maximumCost): de eigenaar heeft expliciet gekozen dat
  // budget uitsluitend zichtbaar/informatief moet zijn (zie
  // mission-engine-v2-panel.tsx) en dat een missie NOOIT mag stoppen of
  // falen vanwege kosten — ook niet via deze invariant, die bij elke
  // mutatie wordt gecontroleerd (zie engine.ts's commit()). Nu er
  // daadwerkelijke kosten worden bijgehouden (zie usage-tracker.ts en
  // pricing.ts), zou deze check anders een cruciale missie halverwege
  // kunnen laten crashen zodra hij toevallig boven het (vaak arbitraire)
  // budget uitkomt — precies wat de eigenaar niet wil.

  const uniqueActiveIds = new Set(mission.activeAssignmentIds);
  if (uniqueActiveIds.size !== mission.activeAssignmentIds.length) {
    throw new Error("activeAssignmentIds bevat duplicaten.");
  }

  for (const assignmentId of mission.activeAssignmentIds) {
    const assignment = mission.assignments.find(
      (candidate) => candidate.assignmentId === assignmentId,
    );
    if (!assignment || assignment.status !== "ACTIVE") {
      throw new Error(`Actieve assignment ${assignmentId} is niet geldig.`);
    }
  }

  if (mission.status === "WAITING_FOR_ROLE" && mission.activeAssignmentIds.length === 0) {
    throw new Error("WAITING_FOR_ROLE vereist minimaal één actieve assignment.");
  }
  if (mission.status === "WAITING_FOR_OWNER" && !mission.pendingOwnerInput) {
    throw new Error("WAITING_FOR_OWNER vereist een open inputverzoek.");
  }
  if (mission.status === "WAITING_FOR_APPROVAL" && !mission.pendingApproval) {
    throw new Error("WAITING_FOR_APPROVAL vereist een open goedkeuringsverzoek.");
  }
  if (mission.status === "COMPLETED") {
    if (mission.activeAssignmentIds.length > 0) {
      throw new Error("Een voltooide mission mag geen actieve assignments hebben.");
    }
    if (mission.successCriteria.some((criterion) => criterion.status !== "PASSED")) {
      throw new Error("Alle succescriteria moeten PASSED zijn voor voltooiing.");
    }
    if (!mission.completedAt) {
      throw new Error("completedAt is verplicht voor een voltooide mission.");
    }
  }
}

export function hasPassedAllCriteria(mission: MissionV2): boolean {
  return mission.successCriteria.every((criterion) => criterion.status === "PASSED");
}
