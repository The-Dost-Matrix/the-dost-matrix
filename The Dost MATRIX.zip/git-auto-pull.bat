@echo off
setlocal

rem ============================================================
rem  Automatische git pull voor The Dost Matrix
rem  Dit script haalt alle nieuwe commits (bijv. missies die de
rem  Director op GitHub heeft gemerged) automatisch binnen in je
rem  lokale map, zonder dat je het zelf hoeft te doen.
rem
rem  Dit bestand hoort NIET bij de git-repo zelf (staat in
rem  .gitignore) - het is puur een hulpmiddel op jouw eigen pc.
rem ============================================================

set "REPO_PATH=D:\The Dost Matrix\the-dost-matrix-git-clone"
set "LOG_FILE=%~dp0git-auto-pull.log"

echo ============================================== >> "%LOG_FILE%"
echo %date% %time% >> "%LOG_FILE%"

cd /d "%REPO_PATH%" 2>>"%LOG_FILE%"
if errorlevel 1 (
    echo FOUT: kan de map niet vinden: %REPO_PATH% >> "%LOG_FILE%"
    endlocal
    exit /b 1
)

git pull >> "%LOG_FILE%" 2>&1

endlocal
